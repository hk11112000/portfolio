const mobileNav = document.querySelector(".mobileNavbarBtn");
const navHeader = document.querySelector('.header');

// navbar collaps JS starts
const toggleNavbar =() =>{
    navHeader.classList.toggle("active")
    navHeader.classList.toggle("header1")   
};
mobileNav.addEventListener('click',() => toggleNavbar())
// navbar collaps JS ends


// Dark mode JS starts
const toggleDM = document.getElementById('toggleDark')
const body = document.querySelector('body');
const header = document.querySelector('header');


toggleDM.addEventListener('click',function(){
    this.classList.toggle('bi-toggle-on')    
})
// Dark mode JS ends


// Contact JS starts
const submit = document.querySelector('.button')
const submitButton=(()=>{
    alert("Success!!\nThis is a Sample Contact Form")
})

// Contact JS ends
