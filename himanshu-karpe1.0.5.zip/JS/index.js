const mobileNav = document.querySelector(".mobileNavbarBtn");
const navHeader = document.querySelector('.header');

const toggleNavbar =() =>{
    navHeader.classList.toggle("active")
    navHeader.classList.toggle("header1")   
};
mobileNav.addEventListener('click',() => toggleNavbar())